FretLab 10.7 for Linux (Original + Beta modes, 100% offline)

Run ./install-linux.sh for a menu entry, or just ./fretlab . Keep the FretLab-files folder next to it.
FretLab serves its files on this computer only (127.0.0.1) and opens your browser.
