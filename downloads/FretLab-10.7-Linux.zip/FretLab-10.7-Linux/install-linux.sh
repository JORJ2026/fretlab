#!/bin/sh
# Installs FretLab for this user: ~/.local/share/fretlab and a menu entry.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/fretlab"
mkdir -p "$DEST" "$HOME/.local/share/applications"
cp -r "$DIR/fretlab" "$DIR/fretlab-x64" "$DIR/fretlab-arm64" "$DIR/fretlab.png" "$DEST/"
rm -rf "$DEST/FretLab-files" && cp -r "$DIR/FretLab-files" "$DEST/"
chmod +x "$DEST/fretlab" "$DEST/fretlab-x64" "$DEST/fretlab-arm64"
cat > "$HOME/.local/share/applications/fretlab.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=FretLab
Comment=Offline fretboard: scales, chords, intervals, tab
Exec=$DEST/fretlab
Icon=$DEST/fretlab.png
Categories=Audio;Music;Education;
Terminal=false
EOF
echo "FretLab installed. Find it in your applications menu, or run $DEST/fretlab"
