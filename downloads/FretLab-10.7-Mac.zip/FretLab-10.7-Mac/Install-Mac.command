#!/bin/bash
# Copies FretLab.app to /Applications and clears the "downloaded from the internet" flag.
cd "$(dirname "$0")" || exit 1
xattr -cr FretLab.app 2>/dev/null
chmod +x FretLab.app/Contents/MacOS/*
rm -rf /Applications/FretLab.app
cp -R FretLab.app /Applications/ && xattr -cr /Applications/FretLab.app 2>/dev/null
echo "FretLab installed in /Applications."
open /Applications/FretLab.app
