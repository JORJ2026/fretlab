@echo off
del "%USERPROFILE%\Desktop\FretLab.lnk" 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\FretLab.lnk" 2>nul
taskkill /IM FretLab.exe /F >nul 2>&1
rmdir /S /Q "%LOCALAPPDATA%\FretLab" 2>nul
echo FretLab removed.
timeout /t 3 >nul
