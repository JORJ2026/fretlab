FretLab 10.7 - Android Studio project (Original + Beta modes, 100% offline)

Open this folder in Android Studio and choose Build > Build APK(s), or run build-apk.sh / build-apk.bat
(needs JDK 17 and the Android SDK). The whole site is in app/src/main/assets/site and is served to the
WebView from a private address, so the app needs no INTERNET permission.
Note: this project could not be compiled where it was made (no Android SDK there); your first build is its first test.
