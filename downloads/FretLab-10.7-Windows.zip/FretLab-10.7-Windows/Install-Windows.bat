@echo off
setlocal
set "SRC=%~dp0"
set "DEST=%LOCALAPPDATA%\FretLab"
set "EXE=FretLab.exe"
if /I "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "EXE=FretLab-arm64.exe"
if not exist "%SRC%%EXE%" (echo Missing %EXE% next to this file. & pause & exit /b 1)
if not exist "%SRC%FretLab-files\index.html" (echo Missing the FretLab-files folder next to this file. & pause & exit /b 1)
taskkill /IM FretLab.exe /F >nul 2>&1
mkdir "%DEST%" 2>nul
copy /Y "%SRC%%EXE%" "%DEST%\FretLab.exe" >nul
copy /Y "%SRC%FretLab.ico" "%DEST%\FretLab.ico" >nul
robocopy "%SRC%FretLab-files" "%DEST%\FretLab-files" /MIR /NFL /NDL /NJH /NJS /NP >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=New-Object -ComObject WScript.Shell; foreach($p in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){$l=$s.CreateShortcut((Join-Path $p 'FretLab.lnk'));$l.TargetPath='%DEST%\FretLab.exe';$l.IconLocation='%DEST%\FretLab.ico';$l.Save()}"
echo FretLab 10.7 installed to %DEST%
echo Shortcuts added to your Desktop and Start menu.
start "" "%DEST%\FretLab.exe"
timeout /t 3 >nul
