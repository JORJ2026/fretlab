package com.fretlab.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * FretLab 8.0 for Android. The whole site (Original and Beta modes) is bundled in assets/site and is served
 * to the WebView from a private https address, so it runs completely offline (the app has no INTERNET permission).
 */
public class MainActivity extends Activity {
    private static final String HOST = "fretlab.app";
    private static final String START = "https://" + HOST + "/index.html";
    private static final Map<String, String> MIME = new HashMap<>();
    static {
        MIME.put("html", "text/html"); MIME.put("htm", "text/html"); MIME.put("js", "text/javascript");
        MIME.put("css", "text/css"); MIME.put("json", "application/json"); MIME.put("png", "image/png");
        MIME.put("jpg", "image/jpeg"); MIME.put("svg", "image/svg+xml"); MIME.put("csv", "text/csv");
        MIME.put("txt", "text/plain"); MIME.put("mid", "audio/midi"); MIME.put("mp3", "audio/mpeg");
        MIME.put("webmanifest", "application/manifest+json"); MIME.put("woff2", "font/woff2"); MIME.put("woff", "font/woff"); MIME.put("pdf", "application/pdf"); MIME.put("gif", "image/gif"); MIME.put("mp4", "video/mp4"); MIME.put("ico", "image/x-icon");
    }
    private WebView web;
    private PermissionRequest pending;

    private WebResourceResponse asset(Uri u) {
        if (u == null || !HOST.equals(u.getHost())) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, null);
        }
        String path = u.getPath();
        if (path == null || path.isEmpty() || path.endsWith("/")) path = (path == null ? "/" : path) + "index.html";
        if (path.contains("..")) return new WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", null, null);
        String ext = path.lastIndexOf('.') >= 0 ? path.substring(path.lastIndexOf('.') + 1).toLowerCase() : "";
        String type = MIME.containsKey(ext) ? MIME.get(ext) : "application/octet-stream";
        try {
            InputStream in = getAssets().open("site" + path);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-cache");
            h.put("Access-Control-Allow-Origin", "https://" + HOST);
            return new WebResourceResponse(type, type.startsWith("text/") || type.contains("javascript") || type.contains("json") ? "utf-8" : null, 200, "OK", h, in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, null);
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.parseColor("#15120F"));
        getWindow().setNavigationBarColor(Color.parseColor("#15120F"));
        // Service-worker requests bypass the WebViewClient, so serve them from the bundled assets too (API 24+).
        ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebResourceRequest req) {
                return asset(req.getUrl());
            }
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#15120F"));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                return asset(req.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                return u == null || !HOST.equals(u.getHost());
            }
        });
        // Lets the tuner ask for the microphone.
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else {
                        pending = req;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
                    }
                });
            }
        });
        // Downloads: the WebView cannot save blob: files, so the page hands exports (PDF, MIDI, Guitar Pro, video…) to the app.
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public String saveFile(String name, String mime, String b64) { return saveDownload(name, mime, b64); }
            @JavascriptInterface
            public void printPage() {
                // window.print() does nothing inside a WebView – use Android's print service (also "Save as PDF").
                runOnUiThread(() -> {
                    try {
                        android.print.PrintManager pm = (android.print.PrintManager) getSystemService(android.content.Context.PRINT_SERVICE);
                        if (pm != null) pm.print("FretLab", web.createPrintDocumentAdapter("FretLab"), null);
                    } catch (Exception e) { Toast.makeText(MainActivity.this, "Printing is not available", Toast.LENGTH_LONG).show(); }
                });
            }
        }, "FretLabAndroid");
        if (state == null) web.loadUrl(START);
        else web.restoreState(state);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 7 && pending != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pending.grant(pending.getResources());
            else pending.deny();
            pending = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    /** Saves an export to Downloads/FretLab (Android 10+) or the app's own Download folder, and opens PDFs. */
    private String saveDownload(String name, String mime, String b64) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            String safe = (name == null || name.isEmpty() ? "fretlab-export" : name).replaceAll("[\\\\/:*?\"<>|]", "_");
            String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            Uri uri = null;
            String where;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, type);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FretLab");
                uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new IOException("could not create the file");
                try (OutputStream os = getContentResolver().openOutputStream(uri)) { os.write(data); }
                where = "Downloads/FretLab/" + safe;
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) dir = getFilesDir();
                File f = new File(dir, safe);
                try (FileOutputStream os = new FileOutputStream(f)) { os.write(data); }
                where = f.getAbsolutePath();
            }
            final Uri open = uri;
            final String msg = "Saved: " + where;
            final boolean pdf = safe.toLowerCase().endsWith(".pdf");
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                if (open != null && pdf) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(open, "application/pdf");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception e) { /* no PDF viewer installed – the file is still in Downloads */ }
                }
            });
            return "ok";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }
}
