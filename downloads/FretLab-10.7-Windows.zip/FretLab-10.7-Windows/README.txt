FretLab 10.7 for Windows (Original + Beta modes, 100% offline)

Run Install-Windows.bat for Desktop and Start-menu shortcuts, or double-click FretLab.exe
(FretLab-arm64.exe on ARM PCs). Keep the exe and the FretLab-files folder together.
FretLab starts a small private server on this computer only (127.0.0.1) and opens your browser.
Nothing is downloaded and nothing leaves your computer. It closes itself after 45 idle minutes.
SmartScreen "unknown publisher": More info > Run anyway (the app is not code-signed).
