FretLab 10.7 for macOS (Original + Beta modes, 100% offline)

Double-click Install-Mac.command, or drag FretLab.app to Applications.
If macOS blocks it: right-click > Open > Open, or run  xattr -cr /Applications/FretLab.app
FretLab serves its files on this Mac only (127.0.0.1) and opens your browser; nothing leaves your Mac.
